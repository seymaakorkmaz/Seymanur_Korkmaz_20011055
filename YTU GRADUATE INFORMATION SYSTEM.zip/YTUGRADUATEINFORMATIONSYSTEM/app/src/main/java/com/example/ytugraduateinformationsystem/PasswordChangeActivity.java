package com.example.ytugraduateinformationsystem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class PasswordChangeActivity extends AppCompatActivity {

   EditText old_pass, new_pass, new_pass2;
   Button save;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_change);
        old_pass = findViewById(R.id.oldpas);
        new_pass = findViewById(R.id.newpas);
        new_pass2 = findViewById(R.id.newpas2);
        save = findViewById(R.id.save);
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        FirebaseUser userAuth = mAuth.getCurrentUser();
        String id = userAuth.getUid();

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!new_pass.getText().toString().equals(new_pass2.getText().toString())){

                    Toast.makeText(PasswordChangeActivity.this, "Passwords are not the same", Toast.LENGTH_SHORT).show();
                    new_pass.setError("Passwords are not match");
                    new_pass2.setError("Passwords are not match");
                }else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(PasswordChangeActivity.this);
                    builder.setTitle("Change Password");
                    builder.setMessage("Are you sure want to change your password?");
                    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

                            user.updatePassword(new_pass.getText().toString())
                                    .addOnCompleteListener(task -> {
                                        if (task.isSuccessful()) {


                                            Map<String, Object> updates = new HashMap<>();
                                            updates.put("password", new_pass.getText().toString());
                                            db.collection("users").document(id)
                                                    .update(updates)
                                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                        @Override
                                                        public void onSuccess(Void aVoid) {

                                                            Toast.makeText(PasswordChangeActivity.this, "Password updated successfully", Toast.LENGTH_SHORT).show();
                                                            Context context = getApplicationContext();

                                                            startActivity(new Intent(context, AnnouncementActivity.class));
                                                        }
                                                    })
                                                    .addOnFailureListener(new OnFailureListener() {
                                                        @Override
                                                        public void onFailure(@NonNull Exception e) {
                                                            //  Log.d(TAG, "Şifre güncelleme başarısız oldu: " + e.getMessage());
                                                        }
                                                    });

                                        } else {
                                            Toast.makeText(PasswordChangeActivity.this, "Password cannot update", Toast.LENGTH_SHORT).show();

                                        }
                                    });



                        }


                    });

                    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();

                        }
                    });

                    builder.show();


                }




            }
        });

    }
}