package com.example.ytugraduateinformationsystem;

import static androidx.core.content.ContextCompat.startActivity;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.io.ObjectInputStream;
import java.util.ArrayList;

public class GraduatesAdapter extends RecyclerView.Adapter<GraduatesAdapter.GraduatesViewHolder>{
    private ArrayList<Graduate> graduatesList;
    private Context context;

    public GraduatesAdapter(ArrayList<Graduate> graduates, Context context) {
        super();
        this.graduatesList = graduates;
        this.context = context;
    }

    @NonNull
    @Override
    public GraduatesAdapter.GraduatesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.recycler_item, parent, false);
        return new GraduatesAdapter.GraduatesViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GraduatesViewHolder holder, int position) {
        Graduate graduate = graduatesList.get(position);

        holder.fullname.setText(graduate.getFullName());
        holder.education_period.setText(graduate.getYear_of_entry() + "-"+ graduate.getYear_of_graduate());

        String imageUrl = graduate.getImageUrl();

        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.person_icon); // isteğe bağlı bir yer tutucu görsel ayarlandı
        requestOptions.fitCenter();
        Glide.with(context)
                .setDefaultRequestOptions(requestOptions)
                .load(imageUrl)
                .into(holder.img);


    }


    @Override
    public int getItemCount() {
        return graduatesList.size();
    }

    public class GraduatesViewHolder extends RecyclerView.ViewHolder {

        TextView fullname, education_period;
        ImageView img;
        CardView cardView;

        public GraduatesViewHolder(@NonNull View itemView) {
            super(itemView);
            fullname = itemView.findViewById(R.id.grad_fullname);
            education_period = itemView.findViewById(R.id.grad_period);
            img = itemView.findViewById(R.id.grad_image);
            cardView = itemView.findViewById(R.id.grad_main_container);
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Get the clicked announcement object
                    Graduate graduate = graduatesList.get(getAdapterPosition());

                    Intent intent = new Intent(context, GraduateProfileActivity.class);
                    intent.putExtra("Graduate", graduate);
                    intent.putExtra("flag",0);
                    context.startActivity(intent);
                }
            });


        }
    }
}

