package com.example.ytugraduateinformationsystem;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.Image;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;

import java.lang.reflect.Field;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class ProfileSettingActivity extends AppCompatActivity {

    EditText email, phone, country, city, company, linkedin, github, twitter, instagram;
    RadioGroup radioGroup;
    Button save;
    ImageView image;
    TextView fullName, education_years;
    FloatingActionButton floatingActionButton;
    DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("users");
    FirebaseStorage storage;
    FirebaseAuth mAuth;
    StorageTask uploadTask;

    StorageReference storageRef;


    FirebaseFirestore db = FirebaseFirestore.getInstance();

    Uri uri;
    String myUri ="";
    private void checkPermissions(){
        boolean res1 = ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED;
        boolean res2 = ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED;

        if(!(res1 && res2)){
            ActivityCompat.requestPermissions(this,new String[]{android.Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE},101);
        }else{
            launchImagePicker();
        }
    }



    private void launchImagePicker() {
        com.github.dhaval2404.imagepicker.ImagePicker.with(ProfileSettingActivity.this)
                .crop()
                .compress(1024)
                .maxResultSize(1080,1080)
                .start();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        uri = data.getData();
        image.setImageURI(uri);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_setting);
        email = findViewById(R.id.grad_email);
        phone = findViewById(R.id.grad_phone);
        country = findViewById(R.id.country);
        city = findViewById(R.id.city);
        company = findViewById(R.id.company);
        linkedin = findViewById(R.id.linkedin_text);
        github = findViewById(R.id.github_text);
        instagram = findViewById(R.id.instagram_text);
        twitter = findViewById(R.id.twitter_text);
        image = findViewById(R.id.image);
        radioGroup = findViewById(R.id.radio_group_education_type);
        save = findViewById(R.id.save_profile);
        floatingActionButton= findViewById(R.id.floatingactionbutton);
        fullName = findViewById(R.id.fullName);
        education_years = findViewById(R.id.education_years);
        Intent intent = getIntent();
        Graduate graduate = intent.getParcelableExtra("Graduate");



        email.setText(graduate.getEmail());
        phone.setText(graduate.getPhoneNumber());
        country.setText(graduate.getCountry());
        city.setText(graduate.getCity());
        company.setText(graduate.getCompany());
        linkedin.setText(graduate.getLinkedin());
        github.setText(graduate.getGithub());
        instagram.setText(graduate.getInstagram());
        twitter.setText(graduate.getTwitter());
        fullName.setText(graduate.getFullName());
        education_years.setText(graduate.getYear_of_entry()+"-"+graduate.getYear_of_graduate());
        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.plecheholder); // isteğe bağlı bir yer tutucu görsel ayarlandı
        requestOptions.fitCenter();
        Glide.with(ProfileSettingActivity.this)
                .setDefaultRequestOptions(requestOptions)
                .load(graduate.getImageUrl())
                .into(image);

        mAuth =FirebaseAuth.getInstance();

        /*
        Map<String, Integer> educationLevels = new HashMap<>();
        educationLevels.put("License", 1);
        educationLevels.put("Graduate", 2);
        educationLevels.put("Doctorate", 3);*/

//        radioGroup.check(educationLevels.get(graduate.getEduction_type()));

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder builder = new AlertDialog.Builder(ProfileSettingActivity.this);
                builder.setTitle("Logout");
                builder.setMessage("Are you sure want to logout?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        if(!Patterns.EMAIL_ADDRESS.matcher(email.getText().toString()).matches()) {
                            email.setError("Email is invaid");
                            //       Toast.makeText(SignUpActivity.this, ,Toast.LENGTH_SHORT).show();
                        }else{/*
                    int selectedId = radioGroup.getCheckedRadioButtonId();
                    if (selectedId != -1) {
                        RadioButton selectedRadioButton = findViewById(selectedId);
                        String education = selectedRadioButton.getText().toString();
                    }*/
                            String email_txt = email.getText().toString();
                            String phone_txt = phone.getText().toString();
                            String country_txt = country.getText().toString();
                            String city_txt = city.getText().toString();
                            String company_txt = company.getText().toString();
                            String linkedin_txt = linkedin.getText().toString();
                            String twitter_txt = twitter.getText().toString();
                            String instagram_txt = instagram.getText().toString();
                            String github_txt = github.getText().toString();

                            storageRef = FirebaseStorage.getInstance().getReference().child("profile pic");
                            Calendar calendar = Calendar.getInstance(); // Anlık tarih ve saat bilgisi
                            int year = calendar.get(Calendar.YEAR); // Yıl bilgisi
                            int month = calendar.get(Calendar.MONTH); // Ay bilgisi (0 - 11)
                            int day = calendar.get(Calendar.DAY_OF_MONTH); // Ayın günü bilgisi
                            int hour = calendar.get(Calendar.HOUR_OF_DAY); // Saat bilgisi (24 saat formatı)
                            int minute = calendar.get(Calendar.MINUTE); // Dakika bilgisi
                            int second = calendar.get(Calendar.SECOND); // Saniye bilgisi
                            FirebaseUser userAuth = mAuth.getCurrentUser();
                            String id = userAuth.getUid();
                            if(uri != null){
                                StorageReference userPhotosRef = storageRef.child(year + "-" + (month+1) + "-" + day + " " + hour + ":" + minute + ":" + second+id+".jpg");
                                uploadTask = userPhotosRef.putFile(uri);

                                uploadTask.continueWithTask(new Continuation() {
                                    @Override
                                    public Object then(@NonNull Task task) throws Exception {
                                        if(!task.isSuccessful()){
                                            throw task.getException();
                                        }
                                        return userPhotosRef.getDownloadUrl();
                                    }
                                }).addOnCompleteListener(new OnCompleteListener() {
                                    @Override
                                    public void onComplete(@NonNull Task task) {
                                        if(task.isSuccessful()){
                                            Uri downloadUrl = (Uri) task.getResult();
                                            myUri = downloadUrl.toString();
                                            Graduate g = new Graduate(graduate.getFullName(),email_txt,graduate.year_of_entry,graduate.year_of_graduate,myUri,graduate.getEduction_type(),company_txt,city_txt,country_txt,instagram_txt,twitter_txt,linkedin_txt,github_txt,phone_txt);
                                            FirebaseUser userAuth = mAuth.getCurrentUser();
                                            String id = userAuth.getUid();
                                            DocumentReference newDocRef = db.collection("users").document(id);
                                            newDocRef.set(g).addOnSuccessListener(new OnSuccessListener<Void>() {
                                                @Override
                                                public void onSuccess(Void aVoid) {
                                                    Toast.makeText(ProfileSettingActivity.this, "Update Completed",Toast.LENGTH_SHORT).show();
                                                }
                                            }).addOnFailureListener(new OnFailureListener() {
                                                @Override
                                                public void onFailure(@NonNull Exception e) {
                                                    // Kayıt işlemi başarısız, kullanıcıya hata mesajı gösterilebilir.
                                                    Toast.makeText(ProfileSettingActivity.this, "Registration failed",Toast.LENGTH_SHORT).show();
                                                }
                                            });
                                        }
                                    }
                                });
                            }else{
                                Graduate g = new Graduate(graduate.getFullName(),email_txt,graduate.year_of_entry,graduate.year_of_graduate,graduate.getImageUrl(),graduate.getEduction_type(),company_txt,city_txt,country_txt,instagram_txt,twitter_txt,linkedin_txt,github_txt,phone_txt);

                                DocumentReference newDocRef = db.collection("users").document(id);
                                newDocRef.set(g).addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        Toast.makeText(ProfileSettingActivity.this, "Update Completed",Toast.LENGTH_SHORT).show();
                                        Context context = getApplicationContext();
                                        Intent intent = new Intent(context, GraduateProfileActivity.class);
                                        intent.putExtra("Graduate",g);
                                        intent.putExtra("flag",1);
                                        startActivity(intent);

                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        // Kayıt işlemi başarısız, kullanıcıya hata mesajı gösterilebilir.
                                        Toast.makeText(ProfileSettingActivity.this, "Registration failed",Toast.LENGTH_SHORT).show();
                                    }
                                });

                            }

                        }

                    }
                });

                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();

                    }
                });

                builder.show();


             }

        });

        floatingActionButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @SuppressLint("QueryPermissionsNeeded")
            @Override
            public void onClick(View v) {
                checkPermissions();
                launchImagePicker();

            }
        });





    }
}