package com.example.ytugraduateinformationsystem;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;
import com.google.firebase.firestore.FirebaseFirestore;

public class MainActivity extends AppCompatActivity {

    EditText email, password;
    Button signin;
    TextView registerRedirect;
    FirebaseAuth auth;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        auth = FirebaseAuth.getInstance();
        email = findViewById(R.id.signinemail);
        password = findViewById(R.id.signinpassword);
        signin = findViewById(R.id.signinbutton);
        registerRedirect = findViewById(R.id.registerRedirectText);



        signin.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {

                  final String email_txt = email.getText().toString();
                  final String password_txt = password.getText().toString();
                  if (email_txt.isEmpty()) {
                      email.setError("Enter your email");
                  } else if (!Patterns.EMAIL_ADDRESS.matcher(email_txt).matches()) {
                      email.setError("Invalid email");
                  } else if (password_txt.isEmpty()) {
                      password.setError("Enter your email");
                  } else {
                      auth.signInWithEmailAndPassword(email_txt, password_txt)
                              .addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                                  @Override
                                  public void onSuccess(AuthResult authResult) {
                                      Toast.makeText(MainActivity.this, "Successfully logged in", Toast.LENGTH_SHORT).show();
                                      startActivity(new Intent(MainActivity.this, AnnouncementActivity.class));

                                      finish();
                                  }
                              }).addOnFailureListener(new OnFailureListener() {
                                  @Override
                                  public void onFailure(@NonNull Exception e) {
                                      Toast.makeText(MainActivity.this, "Wrong Credentials", Toast.LENGTH_SHORT).show();
                                  }
                              });

                  }
              }
          });

        registerRedirect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //open sign up activity
                startActivity(new Intent(MainActivity.this, SignUpActivity.class));
            }
        });
    }


 }