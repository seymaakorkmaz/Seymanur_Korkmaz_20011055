package com.example.ytugraduateinformationsystem;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class AnnouncementActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    private RecyclerView recyclerView;
    Button addButton;
    DrawerLayout drawerLayout;
    FirebaseAuth mAuth;
    Toolbar toolbar;
    private static final String TAG = "AnnouncementActivity";
    FirebaseFirestore db = FirebaseFirestore.getInstance();
    FirebaseStorage storage = FirebaseStorage.getInstance();
    StorageReference storageRef = storage.getReference();

    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_announcement);
        mAuth =FirebaseAuth.getInstance();

        drawerLayout = findViewById(R.id.drawerLayout);
        addButton = findViewById(R.id.btn_bottom_right);
        toolbar = findViewById(R.id.toolBar);
        toolbar.setTitle("ANNOUNCEMENTS");
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setHomeAsUpIndicator(R.drawable.menu); // menü ikonu ayarla
        actionBar.setDisplayHomeAsUpEnabled(true); // toolbar'ı göster
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();




        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));



        CollectionReference newColRef = db.collection("announcements");
        newColRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    // Sorgu başarılı oldu
                    QuerySnapshot querySnapshot = task.getResult();
                    ArrayList<Announcement> announcements = new ArrayList<>();
                    for (QueryDocumentSnapshot documentSnapshot : querySnapshot) {

                        // Doküman verilerini al ve kullan
                        String id = documentSnapshot.getId();
                        System.out.println(id);
                        String title = documentSnapshot.getString("title");
                        String text = documentSnapshot.getString("text");
                        String date = documentSnapshot.getString("date");
                        String image = documentSnapshot.getString("image");
                        String userId = documentSnapshot.getString("userId");
                        Announcement a = new Announcement(text,date,title,image,userId);
                        announcements.add(a);
                    }
                    recyclerView.setAdapter(new AnnouncementAdapter(announcements,AnnouncementActivity.this));
                } else {
                    // Sorgu başarısız oldu
                    Log.d(TAG, "Dokümanlar alınamadı.", task.getException());
                }
            }
        });


        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AnnouncementActivity.this,NewAnnouncementActivity.class));
            }
        });

    }

@Override
public boolean onCreateOptionsMenu(Menu menu) {
    return false;
}

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home: // menü ikonuna tıklanmış
                drawerLayout.openDrawer(GravityCompat.START);
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.nav_announcement:
                recreate();

                break;
            case R.id.nav_media:
               Intent mediaIntent = new Intent(this, MediaActivity.class);
                startActivity(mediaIntent);
                break;
            case R.id.nav_media2:
            Intent mediaIntent2 = new Intent(this, MyMediaActivity.class);
                startActivity(mediaIntent2);
                break;
            case R.id.nav_graduates:
                Intent graduatesIntent = new Intent(this, GraduatesActivity.class);
                startActivity(graduatesIntent);

                break;
            case R.id.nav_profile:
                Intent intent = new Intent(this, GraduateProfileActivity.class);
                FirebaseUser userAuth = mAuth.getCurrentUser();
                String id = userAuth.getUid();
                DocumentReference docRef = db.collection("users").document(id);
                docRef.get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {
                            DocumentSnapshot document = task.getResult();
                            if (document.exists()) {

                                Intent intent = new Intent(AnnouncementActivity.this, GraduateProfileActivity.class);
                                String fullName = document.getString("fullName");
                                String email = document.getString("email");
                                String phone = document.getString("phoneNumber");
                                String imageUrl = document.getString("imageUrl");
                                String education_type = document.getString("educationType");
                                String company = document.getString("company");
                                String country = document.getString("country");
                                String city = document.getString("city");
                                String linkedin = document.getString("linkedin");
                                String github = document.getString("github");
                                String twitter = document.getString("twitter");
                                String instagram = document.getString("instagram");
                                String year_of_entry = document.getString("year_of_entry");
                                String year_of_graduate = document.getString("year_of_graduate");
                                Graduate g = new Graduate(fullName,email,year_of_entry,year_of_graduate,imageUrl,education_type,company,city,country,instagram,twitter,linkedin,github,phone);
                                intent.putExtra("Graduate", g);
                                intent.putExtra("flag",1);
                                startActivity(intent);
                            } else {
                                Log.d(TAG, "Belge bulunamadı");
                            }
                        } else {
                            Log.d(TAG, "Belge alınamadı: ", task.getException());
                        }
                    }
                });

                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}