package com.example.ytugraduateinformationsystem;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

import java.util.ArrayList;

public class Announcement implements Parcelable {
    private String id;
    private String text;
    private String date;
    private String title;
    private String image;
    private String userId;

    public Announcement(){

    }

    public Announcement(String text, String date, String title, String image, String userId) {
        this.text = text;
        this.date = date;
        this.title = title;
        this.image = image;
        this.userId = userId;
    }

    protected Announcement(Parcel in) {
        id = in.readString();
        text = in.readString();
        date = in.readString();
        title = in.readString();
        image = in.readString();
        userId = in.readString();
    }

    public static final Creator<Announcement> CREATOR = new Creator<Announcement>() {
        @Override
        public Announcement createFromParcel(Parcel in) {
            return new Announcement(in);
        }

        @Override
        public Announcement[] newArray(int size) {
            return new Announcement[size];
        }
    };

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(date);
        dest.writeString(text);
        dest.writeString(image);
        dest.writeString(userId);
    }
}
