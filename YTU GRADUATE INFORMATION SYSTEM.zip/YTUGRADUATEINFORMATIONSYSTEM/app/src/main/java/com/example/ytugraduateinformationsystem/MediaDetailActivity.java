package com.example.ytugraduateinformationsystem;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

public class MediaDetailActivity extends AppCompatActivity {

    private String url,title_txt;
    VideoView videoView;
    ImageView imageView;
    TextView title;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_media_detail);
        title = findViewById(R.id.title);
        Intent intent = getIntent();
        url = intent.getStringExtra("url");
        title_txt = intent.getStringExtra("title");
        if (url.contains(".mp4")) {
            // Videoyu göster
            System.out.println("BURADAYIM HEYOOO");
            System.out.println(url);

            videoView = findViewById(R.id.video_view);
            videoView.setVisibility(View.VISIBLE);
            int screenWidth = getResources().getDisplayMetrics().widthPixels;
            int videoWidth = 1920; // video genişliği
            int videoHeight = 1080; // video yüksekliği
            float aspectRatio = (float) videoWidth / videoHeight;
            int calculatedHeight = (int) (screenWidth / aspectRatio);
            videoView.getLayoutParams().height = calculatedHeight;
            videoView.setVideoURI(Uri.parse(url));
            videoView.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    videoView.start();
                }
            });
        }else{
            imageView = findViewById(R.id.image_view);
            RequestOptions requestOptions = new RequestOptions();
            requestOptions.placeholder(R.drawable.plecheholder); // isteğe bağlı bir yer tutucu görsel ayarlandı
            requestOptions.fitCenter();
            Glide.with(MediaDetailActivity.this)
                    .setDefaultRequestOptions(requestOptions)
                    .load(url)
                    .into(imageView);

        }
        title.setText(title_txt);
    }
}