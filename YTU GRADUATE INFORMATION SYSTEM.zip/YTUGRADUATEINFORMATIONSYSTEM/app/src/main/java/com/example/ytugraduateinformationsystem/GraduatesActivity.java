package com.example.ytugraduateinformationsystem;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Locale;

public class GraduatesActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{
    private RecyclerView recyclerView;
    DrawerLayout drawerLayout;
    NavigationView navigationView;
    ActionBarDrawerToggle toggle;
    Toolbar toolbar;
    Button filter;
    ArrayList<String> countries = new ArrayList<>();
    ArrayList<String> cities = new ArrayList<>();


    String selected_country, selected_city;

    FirebaseFirestore db = FirebaseFirestore.getInstance();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graduates);
        Spinner spinner_country = findViewById(R.id.country_spinner);
        Spinner spinner_city = findViewById(R.id.city_spinner);

        drawerLayout = findViewById(R.id.drawerLayoutGraduates);
        toolbar = findViewById(R.id.toolBarGraduates);
        filter = findViewById(R.id.filter);
        toolbar.setTitle("GRADUATES");
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();


        actionBar.setHomeAsUpIndicator(R.drawable.menu); // menü ikonu ayarla

        actionBar.setDisplayHomeAsUpEnabled(true); // toolbar'ı göster
        NavigationView navigationView = findViewById(R.id.nav_view_graduates);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        CollectionReference newColRef = db.collection("users");
        recyclerView = findViewById(R.id.recyclerView2);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));


        countries.add("Country");
        cities.add("City");
        newColRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if (task.isSuccessful()) {
                    // Sorgu başarılı oldu
                    QuerySnapshot querySnapshot = task.getResult();
                    ArrayList<Graduate> graduates = new ArrayList<>();
                    for (QueryDocumentSnapshot documentSnapshot : querySnapshot) {

                        // Doküman verilerini al ve kullan
                        String id = documentSnapshot.getId();
                        String fullName = documentSnapshot.getString("fullName");
                        String image = documentSnapshot.getString("imageUrl");
                        String education_type = documentSnapshot.getString("educatşon_type");
                        String phoneNumber = documentSnapshot.getString("phoneNumber");
                        String email = documentSnapshot.getString("email");
                        String company  = documentSnapshot.getString("company");
                        String city  = documentSnapshot.getString("city");
                        String country  = documentSnapshot.getString("country");
                        String twitter = documentSnapshot.getString("twitter");
                        String github = documentSnapshot.getString("github");
                        String linkedin = documentSnapshot.getString("linkedin");
                        String instagram = documentSnapshot.getString("instagram");
                        String year_of_entry = documentSnapshot.getString("year_of_entry");
                        String year_of_graduate = documentSnapshot.getString("year_of_graduate");


                        countries.add(country);
                        cities.add(city);


                        Graduate g = new Graduate(fullName,email,year_of_entry,year_of_graduate,image,education_type,company,city,country,instagram,twitter,linkedin,github,phoneNumber);
                        graduates.add(g);
                    }
                    recyclerView.setAdapter(new GraduatesAdapter(graduates,GraduatesActivity.this));
                } else {
                    // Sorgu başarısız oldu
                  //  Log.d(TAG, "Dokümanlar alınamadı.", task.getException());
                }
            }
        });

        ArrayAdapter<String> adapter = new ArrayAdapter<>(GraduatesActivity.this, android.R.layout.simple_spinner_item, countries);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner_country.setAdapter(adapter);

        ArrayAdapter<String> adapter2 = new ArrayAdapter<>(GraduatesActivity.this, android.R.layout.simple_spinner_item, cities);
        adapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spinner_city.setAdapter(adapter2);

        spinner_country.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                System.out.println("ADADADADADADDDAA");
                selected_country = parent.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Bir şey seçilmediğinde yapılacak işlemler buraya yazılabilir.
            }
        });


        spinner_city.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selected_city = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Bir şey seçilmediğinde yapılacak işlemler buraya yazılabilir.
            }
        });

        filter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                newColRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        ArrayList<Graduate> graduates = new ArrayList<>();
                        if (task.isSuccessful()) {
                            // Sorgu başarılı oldu
                            QuerySnapshot querySnapshot = task.getResult();
                            String id;
                            String fullName ;
                            String image ;
                            String education_type;
                            String phoneNumber ;
                            String email ;
                            String company;
                            String city  ;
                            String country;
                            String twitter ;
                            String github;
                            String linkedin;
                            String instagram;
;                            String year_of_entry;
                            String year_of_graduate;

                            for (QueryDocumentSnapshot documentSnapshot : querySnapshot) {
                                // Doküman verilerini al ve kullan
                                id = documentSnapshot.getId();
                                fullName = documentSnapshot.getString("fullName");
                                image = documentSnapshot.getString("imageUrl");
                                education_type = documentSnapshot.getString("educatşon_type");
                                phoneNumber = documentSnapshot.getString("phoneNumber");
                                email = documentSnapshot.getString("email");
                                company  = documentSnapshot.getString("company");
                                city  = documentSnapshot.getString("city");
                                country  = documentSnapshot.getString("country");
                                twitter = documentSnapshot.getString("twitter");
                                github = documentSnapshot.getString("github");
                                linkedin = documentSnapshot.getString("linkedin");
                                instagram = documentSnapshot.getString("instagram");
                                year_of_entry = documentSnapshot.getString("year_of_entry");
                                year_of_graduate = documentSnapshot.getString("year_of_graduate");
                                System.out.println(selected_city+"    "+documentSnapshot.getString("city"));
                                if(selected_city.equals("City")){
                                    if(selected_country.equals("Country")){
                                        Graduate g = new Graduate(fullName,email,year_of_entry,year_of_graduate,image,education_type,company,city,country,instagram,twitter,linkedin,github,phoneNumber);
                                        graduates.add(g);
                                    }else if(documentSnapshot.getString("country") != null){
                                        if(documentSnapshot.getString("country").equals(selected_country)) {
                                            Graduate g = new Graduate(fullName,email,year_of_entry,year_of_graduate,image,education_type,company,city,country,instagram,twitter,linkedin,github,phoneNumber);
                                            graduates.add(g);
                                        }
                                    }
                                }else if(selected_country.equals("Country")){
                                    if(documentSnapshot.getString("city") != null ){
                                        if(documentSnapshot.getString("city").equals(selected_city)){

                                            Graduate g = new Graduate(fullName,email,year_of_entry,year_of_graduate,image,education_type,company,city,country,instagram,twitter,linkedin,github,phoneNumber);
                                            graduates.add(g);
                                        }

                                }
                                }else if(documentSnapshot.getString("city") !=null & documentSnapshot.getString("country") != null ){
                                    if(documentSnapshot.getString("city").equals(selected_city) & documentSnapshot.getString("country").equals(selected_country)){

                                        Graduate g = new Graduate(fullName,email,year_of_entry,year_of_graduate,image,education_type,company,city,country,instagram,twitter,linkedin,github,phoneNumber);
                                        graduates.add(g);
                                    }

                                }


                            }
                            recyclerView.setAdapter(new GraduatesAdapter(graduates,GraduatesActivity.this));

                        } else {
                            // Sorgu başarısız oldu
                            //  Log.d(TAG, "Dokümanlar alınamadı.", task.getException());
                        }
                    }
                });

            }
        });



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home: // menü ikonuna tıklanmış
                drawerLayout.openDrawer(GravityCompat.START);
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.nav_announcement:
                Intent announcementIntent = new Intent(this, AnnouncementActivity.class);
                startActivity(announcementIntent);

                break;
            case R.id.nav_media:
                Intent mediaIntent = new Intent(this, MediaActivity.class);
                startActivity(mediaIntent);
                break;

            case R.id.nav_media2:
                Intent mediaIntent2 = new Intent(this, MyMediaActivity.class);
                startActivity(mediaIntent2);
                break;
            case R.id.nav_graduates:
                recreate();

                break;
            case R.id.nav_profile:
               Intent profileIntent = new Intent(this, GraduateProfileActivity.class);
                startActivity(profileIntent);
                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    }
