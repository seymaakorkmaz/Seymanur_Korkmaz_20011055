package com.example.ytugraduateinformationsystem;

import android.os.Parcel;
import android.os.Parcelable;

public class Graduate implements Parcelable {
    String id;
    String fullName;
    String email;
    String year_of_entry,year_of_graduate;
    String password;
    String imageUrl;
    String eduction_type;

    String company, city, country;
    String instagram;
    String twitter;
    String linkedin;
    String github;
    String phoneNumber;

    public Graduate(String fullName, String email, String password, String year_of_entry, String year_of_graduate, String imageUrl) {
        this.fullName = fullName;
        this.email = email;
        this.year_of_entry = year_of_entry;
        this.year_of_graduate = year_of_graduate;
        this.password = password;
        this.imageUrl = imageUrl;
    }

    public Graduate(String fullName, String email, String year_of_entry, String year_of_graduate,String imageUrl, String eduction_type, String company, String city, String country, String instagram, String twitter, String linkedin, String github, String phoneNumber) {
        this.fullName = fullName;
        this.email = email;
        this.year_of_entry = year_of_entry;
        this.year_of_graduate = year_of_graduate;
        this.imageUrl = imageUrl;
        this.eduction_type = eduction_type;
        this.company = company;
        this.city = city;
        this.country = country;
        this.instagram = instagram;
        this.twitter = twitter;
        this.linkedin = linkedin;
        this.github = github;
        this.phoneNumber = phoneNumber;
    }

    protected Graduate(Parcel in) {
        fullName = in.readString();
        email = in.readString();
        year_of_entry = in.readString();
        year_of_graduate = in.readString();
        password = in.readString();
        imageUrl = in.readString();
        eduction_type = in.readString();
        country = in.readString();
        city = in.readString();
        company = in.readString();
        instagram = in.readString();
        twitter = in.readString();
        linkedin = in.readString();
        github = in.readString();
        phoneNumber = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(fullName);
        dest.writeString(email);
        dest.writeString(year_of_entry);
        dest.writeString(year_of_graduate);
        dest.writeString(password);
        dest.writeString(imageUrl);
        dest.writeString(eduction_type);
        dest.writeString(country);
        dest.writeString(city);
        dest.writeString(company);
        dest.writeString(instagram);
        dest.writeString(twitter);
        dest.writeString(linkedin);
        dest.writeString(github);
        dest.writeString(phoneNumber);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Graduate> CREATOR = new Creator<Graduate>() {
        @Override
        public Graduate createFromParcel(Parcel in) {
            return new Graduate(in);
        }

        @Override
        public Graduate[] newArray(int size) {
            return new Graduate[size];
        }
    };

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getYear_of_entry() {
        return year_of_entry;
    }

    public void setYear_of_entry(String year_of_entry) {
        this.year_of_entry = year_of_entry;
    }

    public String getYear_of_graduate() {
        return year_of_graduate;
    }

    public void setYear_of_graduate(String year_of_graduate) {
        this.year_of_graduate = year_of_graduate;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getEduction_type() {
        return eduction_type;
    }

    public void setEduction_type(String eduction_type) {
        this.eduction_type = eduction_type;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getInstagram() {
        return instagram;
    }

    public void setInstagram(String instagram) {
        this.instagram = instagram;
    }

    public String getTwitter() {
        return twitter;
    }

    public void setTwitter(String twitter) {
        this.twitter = twitter;
    }

    public String getLinkedin() {
        return linkedin;
    }

    public void setLinkedin(String linkedin) {
        this.linkedin = linkedin;
    }



    public String getGithub() {
        return github;
    }

    public void setGithub(String github) {
        this.github = github;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
