package com.example.ytugraduateinformationsystem;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.browse.MediaBrowser;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MediaAdapter2 extends RecyclerView.Adapter<MediaAdapter2.MediaViewHolder2> {

    private ArrayList<MediaItem> mediaList;
    private Context context;

    public MediaAdapter2(ArrayList<MediaItem> mediaList, Context context) {
        super();
        this.mediaList = mediaList;
        this.context = context;
    }
    @NonNull
    @Override
    public MediaViewHolder2 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.recycler_media, parent, false);
        return new MediaAdapter2.MediaViewHolder2(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MediaViewHolder2 holder, int position) {
        MediaItem mediaItem = mediaList.get(position);
        System.out.println(mediaItem.getTitle());
        holder.title.setText(mediaItem.getTitle());
        String downloadUrl = mediaItem.getUrl();
        int thumbnailSize = 200;
        Glide.with(context)
                .asBitmap()
                .load(downloadUrl)
                .override(thumbnailSize, thumbnailSize)
                .centerCrop()
                .into(new SimpleTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        // Thumbnail hazır olduğunda buraya gelecektir
                        // ImageView'a thumbnail'ı yükleyin
                        holder.image.setImageBitmap(resource);
                    }
                });


    }

    @Override
    public int getItemCount() {
        return mediaList.size();
    }

    public class MediaViewHolder2 extends RecyclerView.ViewHolder {

        TextView title;
        ImageView image;
        CardView card;
        Button trash;

        public MediaViewHolder2(@NonNull android.view.View itemView) {
            super(itemView);
            int position = getAdapterPosition();
            MediaItem mediaItem = mediaList.get(position);
            title = itemView.findViewById(R.id.id_text2);
            image = itemView.findViewById(R.id.id_image2);
            card = itemView.findViewById(R.id.media_card2);
            trash = itemView.findViewById(R.id.trash_button);


            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    Intent intent = new Intent(context, MediaDetailActivity.class);
                    intent.putExtra("url", mediaItem.getUrl());
                    intent.putExtra("title", mediaItem.getTitle());
                    context.startActivity(intent);
                }

            });

            trash.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(context);
                    builder.setTitle("Logout");
                    builder.setMessage("Are you sure want to delete this media?");
                    builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            DatabaseReference kayitSilRef = FirebaseDatabase.getInstance().getReference("media").child(mediaItem.getId());
                            // Kaydı sil
                            kayitSilRef.removeValue().addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    Toast.makeText(context, "Media deleted successfully", Toast.LENGTH_SHORT).show();

                                }
                            }).addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    Toast.makeText(context, "Media could not be deleted", Toast.LENGTH_SHORT).show();
                                }
                            });

                        }
                    });

                    builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();

                        }
                    });

                    builder.show();
                }
            });






        }
    }
}
