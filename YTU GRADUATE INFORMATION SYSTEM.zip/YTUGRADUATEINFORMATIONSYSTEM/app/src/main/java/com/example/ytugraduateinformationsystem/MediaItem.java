package com.example.ytugraduateinformationsystem;

public class MediaItem {
    String id;
    String title;
    String Url;

    String userId;


    public MediaItem(String id,String title, String url, String userId) {
        this.id =id;
        this.title = title;
        this.Url = url;
        this.userId = userId;

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public MediaItem(String title, String url) {
        this.title = title;
        Url = url;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUrl() {
        return Url;
    }

    public void setUrl(String url) {
        Url = url;
    }
}