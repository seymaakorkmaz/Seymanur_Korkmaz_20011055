package com.example.ytugraduateinformationsystem;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import android.content.Context;
import android.net.Uri;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class AnnouncementDetailActivity extends AppCompatActivity {

    private TextView titleTextView;
    private TextView dateTextView;
    private TextView sourceTextView;
    private ImageView imageView;

    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_announcement_detail);
        // Get the announcement from the intent
        Intent intent = getIntent();
        String title = intent.getStringExtra("title");
        String date = intent.getStringExtra("date");
        String text = intent.getStringExtra("text");
        String image = intent.getStringExtra("image");
        System.out.println(title+""+date+""+text+""+image);
     //   Announcement announcement = intent.getParcelableExtra("announcement");

       // Set up the UI elements
        titleTextView = findViewById(R.id.announcement_title);
        dateTextView = findViewById(R.id.announcement_date);
        sourceTextView = findViewById(R.id.announcement_text);
        imageView = findViewById(R.id.announcement_image);
        titleTextView.setText(title);
        dateTextView.setText(date);

        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(text);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setDoInput(true);

                    InputStream inputStream = connection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line);
                    }

                    bufferedReader.close();
                    inputStream.close();
                    connection.disconnect();

                    return stringBuilder.toString();
                } catch (Exception e) {
                    // Log.e(TAG, "doInBackground: ", e);
                    return null;
                }
            }

            @Override
            protected void onPostExecute(String result) {
                if (result != null) {
                    sourceTextView.setText(result);
                } else {
                    sourceTextView.setText("Error downloading source");
                }
            }
        }.execute();




        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.plecheholder); // isteğe bağlı bir yer tutucu görsel ayarlandı
        requestOptions.fitCenter();
        Glide.with(AnnouncementDetailActivity.this)
                .setDefaultRequestOptions(requestOptions)
                .load(image)
                .into(imageView);


    }



}

