package com.example.ytugraduateinformationsystem;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.browse.MediaBrowser;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.VideoView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.bumptech.glide.request.target.SimpleTarget;
import com.bumptech.glide.request.transition.Transition;
import com.squareup.picasso.Picasso;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class MediaAdapter extends RecyclerView.Adapter<MediaAdapter.MediaViewHolder> {

    private ArrayList<MediaItem> mediaList;
    private Context context;

    public MediaAdapter(ArrayList<MediaItem> mediaList, Context context) {
        super();
        this.mediaList = mediaList;
        this.context = context;
    }
    @NonNull
    @Override
    public MediaViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_image, parent, false);
        return new MediaAdapter.MediaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MediaViewHolder holder, int position) {
        MediaItem mediaItem = mediaList.get(position);
        System.out.println(mediaItem.getTitle());
        holder.title.setText(mediaItem.getTitle());
        String downloadUrl = mediaItem.getUrl();
        int thumbnailSize = 500;
        Glide.with(context)
                .asBitmap()
                .load(downloadUrl)
                .override(thumbnailSize, thumbnailSize)
                .centerCrop()
                .into(new SimpleTarget<Bitmap>() {
                    @Override
                    public void onResourceReady(@NonNull Bitmap resource, @Nullable Transition<? super Bitmap> transition) {
                        // Thumbnail hazır olduğunda buraya gelecektir
                        // ImageView'a thumbnail'ı yükleyin
                         holder.image.setImageBitmap(resource);
                    }
                });

  
    }

    @Override
    public int getItemCount() {
        return mediaList.size();
    }

    public class MediaViewHolder extends RecyclerView.ViewHolder {

     TextView title;
     ImageView image;
     CardView card;

        public MediaViewHolder(@NonNull android.view.View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.id_text);
            image = itemView.findViewById(R.id.id_image);
            card = itemView.findViewById(R.id.media_card);

            card.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();
                    MediaItem mediaItem = mediaList.get(position);

                    Intent intent = new Intent(context, MediaDetailActivity.class);
                    intent.putExtra("url", mediaItem.getUrl());
                    intent.putExtra("title", mediaItem.getTitle());
                    context.startActivity(intent);
                }

            });






        }
    }
}
