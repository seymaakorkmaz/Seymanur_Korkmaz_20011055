package com.example.ytugraduateinformationsystem;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import java.util.Calendar;

public class NewAnnouncementActivity extends AppCompatActivity {

    EditText title, text;
    TextView date;

    ImageView image;
    Uri uri;

    String myUri ="";
    Button add_photo,save;
    FirebaseStorage storage;
    FirebaseAuth mAuth;
    StorageReference storageRef;

    StorageTask uploadTask;
    String date_txt = "";

    FirebaseFirestore db = FirebaseFirestore.getInstance();
    DatabaseReference databaseReference;
    private void checkPermissions(){
        boolean res1 = ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA)== PackageManager.PERMISSION_GRANTED;
        boolean res2 = ContextCompat.checkSelfPermission(this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE)== PackageManager.PERMISSION_GRANTED;

        if(!(res1 && res2)){
            ActivityCompat.requestPermissions(this,new String[]{android.Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE},101);
        }else{
            launchImagePicker();
        }
    }



    private void launchImagePicker() {
        com.github.dhaval2404.imagepicker.ImagePicker.with(NewAnnouncementActivity.this)
                .crop()
                .compress(1024)
                .maxResultSize(1080,1080)
                .start();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(data != null){
            uri = data.getData();
            image.setImageURI(uri);
        }
    }

    private void showDatePickerDialog() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        // Burada seçilen tarihi TextView'e atayabilirsiniz.
                        date.setText(dayOfMonth + "." + (month+1) + "." + year);
                        date_txt = (dayOfMonth + "." + (month+1) + "." + year).toString();
                    }
                },
                Calendar.getInstance().get(Calendar.YEAR),
                Calendar.getInstance().get(Calendar.MONTH),
                Calendar.getInstance().get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();
    }

    public void onCreate(Bundle savedInstanceState) {




        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_announcement);

        storage = FirebaseStorage.getInstance();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("announcements");
        storageRef = FirebaseStorage.getInstance().getReference();
        mAuth =FirebaseAuth.getInstance();
        FirebaseUser userAuth = mAuth.getCurrentUser();

        String id = userAuth.getUid();
        title = findViewById(R.id.titleEditText);
        text = findViewById(R.id.textEditText);
        date = findViewById(R.id.textEditDate);
        add_photo = findViewById(R.id.add);
        save =  findViewById(R.id.save);
        image = findViewById(R.id.add_photo);
        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog();
            }
        });

        add_photo.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @SuppressLint("QueryPermissionsNeeded")
            @Override
            public void onClick(View v) {
                checkPermissions();
                launchImagePicker();

            }
        });


        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String title_txt = title.getText().toString();
                final String main_text = text.getText().toString();



                CollectionReference newColRef = db.collection("announcements");

                if(uri != null){
                      FirebaseUser userAuth = mAuth.getCurrentUser();

                      String id = userAuth.getUid();
                      StorageReference announcementPhotosRef = storageRef.child("announcement pic").child(id+title_txt+".jpg");
                      uploadTask = announcementPhotosRef.putFile(uri);

                      uploadTask.continueWithTask(new Continuation() {
                          @Override
                          public Object then(@NonNull Task task) throws Exception {
                                if(!task.isSuccessful()){
                                    throw task.getException();
                                }
                                return announcementPhotosRef.getDownloadUrl();
                            }
                      }).addOnCompleteListener(new OnCompleteListener() {
                                @Override
                           public void onComplete(@NonNull Task task) {
                                if(task.isSuccessful()){
                                    Uri downloadUrl = (Uri) task.getResult();
                                    myUri = downloadUrl.toString();

                                    // Yeni bir TXT dosyası oluştur
                                    StorageReference txtRef = storageRef.child("announcements").child(id+"-"+title_txt+".txt");
                                    byte[] bytes = main_text.getBytes();
                                    UploadTask uploadTask = txtRef.putBytes(bytes);
                                    uploadTask.addOnSuccessListener(taskSnapshot -> {
                                        txtRef.getDownloadUrl().addOnSuccessListener(uri -> {
                                            String url = uri.toString();
                                            FirebaseUser userAuth = mAuth.getCurrentUser();
                                            String userId = userAuth.getUid();
                                            System.out.println(userId);
                                            Announcement announcement = new Announcement(url, date_txt, title_txt, myUri, userId);
                                            DocumentReference newDocRef = db.collection("announcements").document();
                                            newDocRef
                                                .set(announcement).addOnSuccessListener(new OnSuccessListener<Void>() {
                                                    @Override
                                                    public void onSuccess(Void unused) {
                                                        db.collection("announcements").document(newDocRef.getId()).update("userId", userId)
                                                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                                                    @Override
                                                                    public void onSuccess(Void aVoid) {
                                                                        Toast.makeText(NewAnnouncementActivity.this, "Announcement Saved",Toast.LENGTH_SHORT).show();
                                                                       Context context = getApplicationContext();
                                                                        startActivity(new Intent(context, AnnouncementActivity.class));

                                                                    }
                                                                })
                                                                .addOnFailureListener(new OnFailureListener() {
                                                                    @Override
                                                                    public void onFailure(@NonNull Exception e) {

                                                                        Toast.makeText(NewAnnouncementActivity.this, "Failed to Load Announcement",Toast.LENGTH_SHORT).show();
                                                                    }
                                                                });
                                                    }
                                                })
                                                .addOnFailureListener(new OnFailureListener() {
                                                    @Override
                                                    public void onFailure(@NonNull Exception e) {
                                                        Toast.makeText(NewAnnouncementActivity.this, "Failed to Load Announcement",Toast.LENGTH_SHORT).show();
                                                    }
                                                });

                                        });
                                    }).addOnFailureListener(exception -> {

                                        Toast.makeText(NewAnnouncementActivity.this, "Failed to Load Announcement",Toast.LENGTH_SHORT).show();
                                    });


                                    }
                                }
                            });
                        }
                    }



        });

    }


}
