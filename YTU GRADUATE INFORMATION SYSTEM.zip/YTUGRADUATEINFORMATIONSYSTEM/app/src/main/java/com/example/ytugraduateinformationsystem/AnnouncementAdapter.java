package com.example.ytugraduateinformationsystem;

import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class AnnouncementAdapter extends RecyclerView.Adapter<AnnouncementAdapter.AnnouncementViewHolder> {

    private ArrayList<Announcement> announcementList;
    private Context context;
    public AnnouncementAdapter(ArrayList<Announcement> announcements, Context context) {
        super();
        this.announcementList = announcements;
        this.context = context;
    }


    @NonNull
    @Override
    public AnnouncementViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.headline_list_items, parent, false);
        return new AnnouncementViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AnnouncementViewHolder holder, int position) {
        Announcement announcement = announcementList.get(position);

        holder.title.setText(announcement.getTitle());
        holder.date.setText(announcement.getDate());


        new AsyncTask<Void, Void, String>() {
            @Override
            protected String doInBackground(Void... voids) {
                try {
                    URL url = new URL(announcement.getText());
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setDoInput(true);

                    InputStream inputStream = connection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));

                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line);
                    }

                    bufferedReader.close();
                    inputStream.close();
                    connection.disconnect();

                    return stringBuilder.toString();
                } catch (Exception e) {
                   // Log.e(TAG, "doInBackground: ", e);
                    return null;
                }
            }

            @Override
            protected void onPostExecute(String result) {
                if (result != null) {
                    holder.source.setText(result);
                } else {
                    holder.source.setText("Error downloading source");
                }
            }
        }.execute();


        String imageUrl = announcement.getImage();

        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.plecheholder); // isteğe bağlı bir yer tutucu görsel ayarlandı
        requestOptions.fitCenter();
        Glide.with(context)
                .setDefaultRequestOptions(requestOptions)
                .load(imageUrl)
                .into(holder.img_headline);


    }

    @Override
    public int getItemCount() {
        return announcementList.size();
    }

    public class AnnouncementViewHolder extends RecyclerView.ViewHolder {

        TextView source,date,title;
        ImageView img_headline;
        CardView cardView;


        public AnnouncementViewHolder(@NonNull View itemView) {
            super(itemView);

            title = itemView.findViewById(R.id.text_title);
            source = itemView.findViewById(R.id.text_source);
            date = itemView.findViewById(R.id.text_date);
            img_headline = itemView.findViewById(R.id.img_headline);
            cardView = itemView.findViewById(R.id.main_container);
            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Get the clicked announcement object
                    Announcement announcement = announcementList.get(getAdapterPosition());

                    Intent intent = new Intent(context, AnnouncementDetailActivity.class);
                    intent.putExtra("id",announcement.getId());
                    intent.putExtra("title",announcement.getTitle());
                    intent.putExtra("date",announcement.getDate());
                    intent.putExtra("image",announcement.getImage());
                    intent.putExtra("text",announcement.getText());
                    context.startActivity(intent);
                }

            });



        }
    }

}
